
path_to_config=$1

python lm_train.py $1